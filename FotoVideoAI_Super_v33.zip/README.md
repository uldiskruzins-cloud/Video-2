# FotoVideo AI Super v3.2

### Mevada build fix
The Gradle launcher now first uses an already-installed `gradle` binary in the cloud builder. It downloads Gradle only if no Gradle installation exists. This avoids unnecessary network fetching on builders that already provide Gradle.

### Alternative cloud build
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

### App
Photo -> AI video interface with Runway integration, 5/10/15 seconds, aspect ratios, prompts, preview and save.
