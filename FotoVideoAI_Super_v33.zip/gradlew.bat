@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set V=8.9
set BASE=%USERPROFILE%\.gradle\wrapper\dists\fotovideo-gradle\%V%
set DIST=%BASE%\gradle-%V%
set BIN=%DIST%\bin\gradle.bat
if not exist "%BIN%" (
  powershell -NoProfile -Command "$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force '%BASE%' | Out-Null; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%V%-bin.zip' -OutFile '%BASE%\gradle.zip'; Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'"
)
call "%BIN%" %*
