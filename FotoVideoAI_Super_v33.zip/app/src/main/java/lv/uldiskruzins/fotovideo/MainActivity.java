package lv.uldiskruzins.fotovideo;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.media.MediaPlayer;

import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    static final String API = "https://api.dev.runwayml.com";
    static final String VERSION = "2024-11-06";
    ImageView image;
    VideoView video;
    EditText key, prompt;
    Spinner ratio, duration;
    Switch audio;
    TextView status;
    Uri photo;
    Uri resultVideo;
    android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("settings",0);

        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);
        scroll.addView(root);

        TextView title=new TextView(this);
        title.setText("FotoVideo AI");
        title.setTextSize(30);
        root.addView(title);

        TextView sub=new TextView(this);
        sub.setText("Foto → reālistisks AI video • 15 sekundes");
        sub.setTextSize(16);
        root.addView(sub);

        image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(image,new LinearLayout.LayoutParams(-1,650));

        video=new VideoView(this);
        video.setVisibility(View.GONE);
        root.addView(video,new LinearLayout.LayoutParams(-1,650));

        Button choose=new Button(this);
        choose.setText("🖼 Izvēlēties foto");
        choose.setOnClickListener(v->pickPhoto());
        root.addView(choose);

        prompt=new EditText(this);
        prompt.setHint("Apraksti kustību…");
        prompt.setText("Fotoreālistiska dabiska kustība, cilvēks viegli elpo un dabiski mirkšķina, mati un apģērbs viegli kustas vējā, kamera lēnām un vienmērīgi tuvojas, saglabāt sejas un ķermeņa identitāti, reālistisks apgaismojums un fizika.");
        prompt.setMinLines(4);
        root.addView(prompt);

        TextView presets=new TextView(this);
        presets.setText("Ātrie režīmi:");
        root.addView(presets);

        LinearLayout pRow=new LinearLayout(this);
        String[] ps={"Dabisks","Kameras kustība","Kustība vējā","Kinematogrāfisks"};
        for(String s:ps){
            Button x=new Button(this); x.setText(s);
            x.setOnClickListener(v->applyPreset(((Button)v).getText().toString()));
            pRow.addView(x,new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(pRow);

        key=new EditText(this);
        key.setHint("Runway API atslēga");
        key.setInputType(0x81);
        key.setText(prefs.getString("key",""));
        root.addView(key);

        ratio=new Spinner(this);
        ratio.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"16:9 — 1280×720","9:16 — 720×1280","1:1 — 960×960","16:9 — 1920×1080"}));
        root.addView(ratio);

        duration=new Spinner(this);
        duration.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"15 sekundes","10 sekundes","5 sekundes"}));
        ratio.setSelection(0); duration.setSelection(0);
        root.addView(duration);

        audio=new Switch(this);
        audio.setText("Ģenerēt arī AI audio");
        audio.setChecked(true);
        root.addView(audio);

        Button go=new Button(this);
        go.setText("✨ ĢENERĒT REĀLISTISKU VIDEO");
        go.setTextSize(17);
        go.setOnClickListener(v->generate());
        root.addView(go);

        Button save=new Button(this);
        save.setText("💾 SAGLABĀT VIDEO");
        save.setOnClickListener(v->saveVideo());
        root.addView(save);

        status=new TextView(this);
        status.setText("Izvēlies foto. Pēc tam ievadi savu Runway API atslēgu.");
        status.setPadding(0,20,0,20);
        root.addView(status);

        setContentView(scroll);
    }

    void applyPreset(String s){
        String base;
        if(s.equals("Kameras kustība")) base="Fotoreālistiska aina. Kamera lēnām veic gludu orbitālu kustību ap galveno objektu, viegls dolly-in, dabisks dziļums un perspektīva, objekts paliek konsekvents.";
        else if(s.equals("Kustība vējā")) base="Fotoreālistiska dabiska kustība. Maigs vējš kustina matus, drēbes un apkārtējo veģetāciju, cilvēks dabiski elpo un mirkšķina, kamera viegli kustas.";
        else if(s.equals("Kinematogrāfisks")) base="Fotoreālistiska kinematogrāfiska aina, lēns dolly shot, dabisks objektīva dziļums, maigas gaismas izmaiņas, reālistiska fizika, saglabāt galvenā objekta identitāti.";
        else base="Fotoreālistiska dabiska kustība, cilvēks dabiski elpo un mirkšķina, mati un apģērbs viegli kustas, kamera ļoti lēni tuvojas, saglabāt sejas un ķermeņa identitāti.";
        prompt.setText(base);
    }

    void pickPhoto(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,42);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==42 && c==RESULT_OK && d!=null){
            photo=d.getData(); image.setImageURI(photo);
            image.setVisibility(View.VISIBLE); video.setVisibility(View.GONE);
            status.setText("Foto izvēlēts.");
        }
    }

    String ratioValue(){
        int p=ratio.getSelectedItemPosition();
        if(p==1)return "720:1280";
        if(p==2)return "960:960";
        if(p==3)return "1920:1080";
        return "1280:720";
    }
    int durationValue(){ int p=duration.getSelectedItemPosition(); return p==1?10:(p==2?5:15); }

    void generate(){
        if(photo==null){toast("Vispirms izvēlies foto.");return;}
        String token=key.getText().toString().trim();
        if(token.isEmpty()){toast("Ievadi Runway API atslēgu.");return;}
        prefs.edit().putString("key",token).apply();
        String p=prompt.getText().toString().trim();
        if(p.isEmpty()){toast("Ievadi kustības aprakstu.");return;}

        status.setText("1/3 Sagatavoju foto…");
        new Thread(()->{
            try{
                String dataUri=imageDataUri(photo);
                runOnUiThread(()->status.setText("2/3 AI ģenerē video…"));
                JSONObject body=new JSONObject();
                body.put("version","2026-06");
                body.put("mode","auto");
                body.put("prompt",p);
                body.put("duration",durationValue());
                body.put("ratio",ratioValue());
                body.put("audio",audio.isChecked());
                JSONObject first=new JSONObject(); first.put("uri",dataUri);
                body.put("firstFrame",first);

                String task=create(token,body);
                String url=poll(token,task);
                runOnUiThread(()->status.setText("3/3 Lejupielādēju rezultātu…"));
                File out=new File(getExternalFilesDir(null),"FotoVideo_"+System.currentTimeMillis()+".mp4");
                download(url,out);
                runOnUiThread(()->{
                    resultVideo=Uri.fromFile(out);
                    image.setVisibility(View.GONE); video.setVisibility(View.VISIBLE);
                    video.setVideoURI(resultVideo); video.start();
                    status.setText("✅ Gatavs! AI video izveidots.");
                });
            }catch(Exception e){
                runOnUiThread(()->{status.setText("❌ "+e.getMessage());});
            }
        }).start();
    }

    String imageDataUri(Uri u)throws Exception{
        String mime=getContentResolver().getType(u);
        if(mime==null) mime="image/jpeg";
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        try(InputStream in=getContentResolver().openInputStream(u)){
            byte[] b=new byte[1024*1024]; int n;
            while((n=in.read(b))!=-1) bos.write(b,0,n);
        }
        return "data:"+mime+";base64,"+
                android.util.Base64.encodeToString(bos.toByteArray(),android.util.Base64.NO_WRAP);
    }

    File copyToCache(Uri u)throws Exception{
        File f=new File(getCacheDir(),"input.jpg");
        try(InputStream in=getContentResolver().openInputStream(u); OutputStream out=new FileOutputStream(f)){
            byte[] b=new byte[1024*1024]; int n; while((n=in.read(b))>0)out.write(b,0,n);
        }
        return f;
    }

    String upload(String token,File file)throws Exception{
        JSONObject init=new JSONObject();
        init.put("filename","photo.jpg"); init.put("type","ephemeral");
        JSONObject r=postJson(API+"/v1/uploads",init,token);
        String uploadUrl=r.getString("uploadUrl");
        JSONObject fields=r.getJSONObject("fields");
        String boundary="----FotoVideo"+System.currentTimeMillis();
        URL u=new URL(uploadUrl);
        HttpURLConnection c=(HttpURLConnection)u.openConnection();
        c.setDoOutput(true); c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        try(OutputStream out=c.getOutputStream()){
            for(String k:fields.keySet()){
                part(out,boundary,k,fields.getString(k));
            }
            out.write(("--"+boundary+"\\r\\nContent-Disposition: form-data; name=\"file\"; filename=\"photo.jpg\"\\r\\nContent-Type: image/jpeg\\r\\n\\r\\n").getBytes());
            try(InputStream in=new FileInputStream(file)){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);}
            out.write(("\\r\\n--"+boundary+"--\\r\\n").getBytes());
        }
        if(c.getResponseCode()/100!=2)throw new Exception("Foto augšupielāde neizdevās: "+c.getResponseCode());
        return r.getString("runwayUri");
    }

    void part(OutputStream out,String b,String name,String value)throws Exception{
        out.write(("--"+b+"\\r\\nContent-Disposition: form-data; name=\""+name+"\"\\r\\n\\r\\n"+value+"\\r\\n").getBytes());
    }

    String create(String token,JSONObject body)throws Exception{
        JSONObject r=postJson(API+"/v1/recipes/multi_shot_video",body,token);
        return r.getString("id");
    }

    String poll(String token,String id)throws Exception{
        for(int i=0;i<120;i++){
            Thread.sleep(5000);
            JSONObject r=getJson(API+"/v1/tasks/"+id,token);
            String s=r.optString("status");
            if("SUCCEEDED".equals(s)){
                JSONArray a=r.getJSONArray("output");
                return a.getString(0);
            }
            if("FAILED".equals(s)||"CANCELED".equals(s)){
                String fc=r.optString("failureCode","unknown");
                throw new Exception("AI ģenerēšana neizdevās: "+fc);
            }
            final int n=i+1;
            runOnUiThread(()->status.setText("2/3 AI ģenerē video… "+n*5+" s"));
        }
        throw new Exception("AI ģenerēšana pārsniedza gaidīšanas laiku.");
    }

    JSONObject postJson(String url,String body,String token)throws Exception{
        return postJson(url,new JSONObject(body),token);
    }
    JSONObject postJson(String url,JSONObject body,String token)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setDoOutput(true);c.setRequestMethod("POST");
        c.setRequestProperty("Authorization","Bearer "+token);
        c.setRequestProperty("X-Runway-Version",VERSION);
        c.setRequestProperty("Content-Type","application/json");
        try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes("UTF-8"));}
        return readJson(c);
    }
    JSONObject getJson(String url,String token)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestProperty("Authorization","Bearer "+token);
        c.setRequestProperty("X-Runway-Version",VERSION);
        return readJson(c);
    }
    JSONObject readJson(HttpURLConnection c)throws Exception{
        int code=c.getResponseCode();
        InputStream in=code>=400?c.getErrorStream():c.getInputStream();
        String s=read(in);
        if(code/100!=2)throw new Exception("API kļūda "+code+": "+s);
        return new JSONObject(s);
    }
    String read(InputStream in)throws Exception{
        StringBuilder s=new StringBuilder();byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1)s.append(new String(b,0,n,"UTF-8"));
        return s.toString();
    }
    void download(String u,File f)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(f)){
            byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
        }
    }
    void saveVideo(){
        if(resultVideo==null){toast("Vispirms izveido video.");return;}
        try{
            ContentValues v=new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME,"FotoVideoAI_"+System.currentTimeMillis()+".mp4");
            v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH,android.os.Environment.DIRECTORY_MOVIES+"/FotoVideoAI");
            Uri dest=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);
            try(InputStream in=new FileInputStream(new File(resultVideo.getPath()));OutputStream out=getContentResolver().openOutputStream(dest)){
                byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            }
            toast("Video saglabāts galerijā.");
        }catch(Exception e){toast("Saglabāšana neizdevās: "+e.getMessage());}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
